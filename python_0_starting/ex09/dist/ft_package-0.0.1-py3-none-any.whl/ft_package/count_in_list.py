def count_in_list(list, name):
    return list.count(name)
